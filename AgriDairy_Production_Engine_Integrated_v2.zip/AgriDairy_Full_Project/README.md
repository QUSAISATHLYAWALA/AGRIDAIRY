# AgriDairy Full Project Package

This ZIP combines your uploaded AgriDairy frontend with a new FastAPI + SQLite backend starter.

## Structure
- `frontend/index.html` — your uploaded Blinkit-inspired AgriDairy interface.
- `backend/app/main.py` — FastAPI backend and production prediction API.
- `production_engine/agridairy_engine/` — combined dairy/crop ML engine and model storage.
- `production_engine/data_templates/` — CSV column templates for real training records.
- `backend/requirements.txt` — Python dependencies.
- `START_AGRIDAIRY_WINDOWS.bat` — Windows setup and launch script.

## Run on Windows
1. Install Python 3.11 or newer.
2. Extract this ZIP.
3. Double-click `START_AGRIDAIRY_WINDOWS.bat`.
4. Open `http://127.0.0.1:8000`.
5. API docs: `http://127.0.0.1:8000/docs`.
6. Health check: `http://127.0.0.1:8000/api/health`.

The SQLite database is created automatically in `backend/data/`.

## API routes included
- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `GET /api/products`
- `POST /api/products`
- `GET /api/inventory`
- `GET /api/orders`
- `POST /api/orders`
- `PATCH /api/orders/{order_id}/status`

## Integration status — please read
The frontend HTML is preserved from your uploaded file. Its authentication calls already match the backend routes in this package. The backend also has basic product, inventory and order APIs.

However, **not every marketplace screen is migrated to the database yet**. A number of existing modules still use browser `localStorage`. This ZIP is the complete project folder (frontend + backend starter), not a claim that every module is fully integrated or production-ready. The next engineering task is to migrate marketplace product listings, inventory, checkout, farm records, processing, quality, logistics and admin workflows to the API and test them end to end.

New accounts start `Under Review`, so they cannot log in until verified. Do not use this development package for live customer transactions.

Before deployment, configure a strong secret, HTTPS and secure cookies, CSRF protection, rate limiting, admin approval controls, audit logs, backups and production database infrastructure.


## Production prediction engine (new)
The app now includes separate dairy and crop production prediction modules. Open the app and select **Production Forecast** (floating button). The panel supports saving actual farm records, viewing verified record counts/model metrics, requesting a prediction, and admin-only model training.

- Dairy target: `actual_milk_litres_day` per animal-day.
- Crop target: `actual_yield_kg_per_ha` per crop-season, using pre-harvest features only.
- Models require at least 50 supplier-submitted actual records from verified accounts each. No synthetic/demo records are used for training.
- Only verified Dairy/Farm-Agriculture accounts can save their own records. Only Admin can train models.
- Model artifacts are stored under `production_engine/agridairy_engine/trained_models/`; source records and metrics are in the SQLite database.
- A forecast is not actual/saleable inventory. Confirm weighing/milking, quality, losses, reserves and commitments separately.

**Important integration boundary:** the existing marketplace inventory/order system remains separate from forecast values. Forecasts do not automatically create stock or alter marketplace availability. The floating panel calls the FastAPI backend and therefore requires a verified backend session; the old browser demo login is not the same as backend authentication.

Record quality is still an operational responsibility: account verification does not independently prove each production figure. An administrator should review milking logs, weigh slips and season records before training.
