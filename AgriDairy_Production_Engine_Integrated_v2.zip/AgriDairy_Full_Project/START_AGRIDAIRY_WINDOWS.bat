@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.11 or newer is required. Install Python and try again.
  pause
  exit /b 1
)
if not exist "backend\.venv\Scripts\python.exe" (
  echo Creating virtual environment...
  py -3 -m venv backend\.venv
  if errorlevel 1 (echo Could not create virtual environment.& pause & exit /b 1)
)
echo Installing dependencies...
backend\.venv\Scripts\python.exe -m pip install --upgrade pip
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if errorlevel 1 (echo Dependency installation failed.& pause & exit /b 1)
echo.
echo AgriDairy is starting at http://127.0.0.1:8000
echo API docs: http://127.0.0.1:8000/docs
echo Press CTRL+C to stop.
cd backend
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
pause
