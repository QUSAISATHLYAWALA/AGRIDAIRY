from agridairy_engine.production_engine import predict_dairy, predict_crop, dairy_farm_summary, crop_farm_summary

# Replace these example values with actual farm measurements.
dairy_features = {
    "animal_type":"Cow", "breed":"Jersey", "age_months":48, "weight_kg":420,
    "parity":2, "days_in_milk":90, "days_since_calving":90,
    "lactation_stage":"mid", "feed_quality_score":7.5, "feed_kg_per_day":18,
    "water_litres_per_day":65, "health_stress_score":0,
    "milk_7d_avg_litres":14, "milk_30d_avg_litres":13.5,
    "season_month":11, "farm_region":"Maharashtra"
}
crop_features = {
    "crop":"Wheat", "variety":"Local variety", "farm_region":"Maharashtra",
    "soil_type":"Loam", "irrigation_type":"Canal", "area_hectares":1.0,
    "soil_ph":6.8, "organic_matter_pct":0.8,
    "nitrogen_kg_per_ha":90, "phosphorus_kg_per_ha":40, "potassium_kg_per_ha":40,
    "rainfall_to_date_mm":120, "irrigation_mm":80, "mean_temp_c":22,
    "max_temp_c":30, "solar_radiation_mj_m2":18, "soil_moisture_pct":22,
    "pest_severity":1, "disease_severity":0, "weed_severity":1,
    "ndvi_current":0.65, "sowing_month":11, "days_after_sowing":60,
    "previous_crop":"Soybean", "previous_yield_kg_per_ha":2800
}

# Requires trained models in agridairy_engine/trained_models/.
# dairy = predict_dairy(dairy_features)
# crop = predict_crop(crop_features)
# print(dairy.to_dict())
# print(crop.to_dict())
