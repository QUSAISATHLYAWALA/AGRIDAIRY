# AgriDairy Combined Production Prediction Engine

This combines the useful ideas from the two supplied algorithms, while removing the most important weaknesses.

## What is included
- Separate dairy and crop prediction models.
- Random Forest pipelines with missing-value handling and one-hot encoding.
- Dairy inputs include species, breed, age, weight, parity, lactation stage, days in milk, feed, water, health and recent milk history.
- Crop inputs include crop/variety, region, soil, NPK, rainfall, irrigation, weather, pest/disease pressure, current NDVI, sowing month and days after sowing.
- Model evaluation with MAE, RMSE and R².
- Group-based train/test holdout (by animal/farm where possible).
- Tree-spread indicative range.
- Farm-level aggregation helpers.
- CSV templates for real training records.

## Crucial difference from the supplied algorithms
The supplied files use generated/example records and report scores on those records. Those scores do not prove real-world accuracy. This engine does not generate fake training data or claim a score until trained and evaluated on your actual records.

## Install
Python 3.10+ recommended.

```bash
pip install -r requirements.txt
```

## Prepare real data
Fill:
- `data_templates/dairy_training_template.csv`: one row per animal per day (or consistent animal recording period), with actual measured milk litres in `actual_milk_litres_day`.
- `data_templates/crop_training_template.csv`: one row per farm/crop/season with pre-harvest measurements and actual harvested yield per hectare in `actual_yield_kg_per_ha`.

Use consistent units. Do not mix litres/day with litres/month, or kg/acre with kg/hectare. Use India-relevant farms, breeds, crops, regions and seasons.

## Train

From this folder:

```bash
python train_models.py --dairy data_templates/dairy_training_template.csv --crop data_templates/crop_training_template.csv
```

The blank templates are schemas only; training will correctly fail until real rows are added. A minimum of 50 rows is required by default. More data, multiple farms and seasons are strongly recommended.

## Predict
See `examples.py` for sample feature dictionaries. First train a model and then call:
- `predict_dairy(features)` -> litres per animal per day.
- `predict_crop(features)` -> kg per hectare.
- `dairy_farm_summary(...)` -> farm daily/monthly planning estimate.
- `crop_farm_summary(...)` -> total harvest estimate from area.

## Important operational rules for AgriDairy
1. Prediction is not confirmed supply.
2. Actual measured output should update farm records and be used for future retraining.
3. Saleable inventory must be based on confirmed stock and quality checks, minus reserved/committed quantities—not predicted production.
4. The displayed lower/upper range is based on variation across Random Forest trees. It is only indicative and is not a calibrated 80% confidence interval.
5. Validate on later seasons and farms not used for training before using predictions for procurement decisions.
6. Do not use harvest date, final yield, post-harvest NDVI, or other future information as pre-harvest model inputs.
7. A qualified agronomist/dairy specialist should review the feature definitions and local assumptions.

## Known limitations
- No real AgriDairy farm data was supplied, so no model has been trained and no accuracy claim is possible yet.
- The model does not fetch weather, satellite or soil data automatically.
- Feed quality, health stress, soil moisture, pest severity and other scores need agreed definitions and consistent collection.
- Random Forest feature importance is not causal evidence.
- Production estimates are decision support, not veterinary or agronomy advice.
