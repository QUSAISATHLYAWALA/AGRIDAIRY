import argparse, json
from agridairy_engine.production_engine import train_dairy_model, train_crop_model

p = argparse.ArgumentParser(description="Train AgriDairy dairy and crop models from verified records.")
p.add_argument("--dairy", help="Path to dairy CSV")
p.add_argument("--crop", help="Path to crop CSV")
p.add_argument("--min-rows", type=int, default=50)
args = p.parse_args()
if not args.dairy and not args.crop:
    p.error("Provide --dairy and/or --crop.")
if args.dairy:
    print("DAIRY MODEL")
    print(json.dumps(train_dairy_model(args.dairy, min_rows=args.min_rows), indent=2))
if args.crop:
    print("CROP MODEL")
    print(json.dumps(train_crop_model(args.crop, min_rows=args.min_rows), indent=2))
