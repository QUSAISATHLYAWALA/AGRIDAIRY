"""
AgriDairy Production Prediction Engine
======================================

Two separate supervised models:
- Dairy: daily milk litres per animal.
- Crops: harvest kg per hectare.

Important:
* Train only on verified historical farm records.
* Do not train on synthetic/demo rows and present the score as real accuracy.
* Crop predictions are pre-harvest: harvest date, final harvest quantity and
  post-harvest NDVI must not be supplied as prediction features.
* Dairy predictions are per animal; farm totals are aggregated separately.
* Estimated production is not saleable inventory. Inventory must subtract
  committed orders, losses, reserves and quality holds elsewhere in the app.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Optional
import json
import math
import warnings

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
import joblib


ENGINE_VERSION = "1.0.0"
MODEL_DIR = Path(__file__).resolve().parent / "trained_models"

DAIRY_NUMERIC = [
    "age_months", "weight_kg", "parity", "days_in_milk",
    "days_since_calving", "feed_quality_score", "feed_kg_per_day",
    "water_litres_per_day", "health_stress_score",
    "milk_7d_avg_litres", "milk_30d_avg_litres",
    "season_month",
]
DAIRY_CATEGORICAL = ["animal_type", "breed", "lactation_stage", "farm_region"]

CROP_NUMERIC = [
    "area_hectares", "soil_ph", "organic_matter_pct",
    "nitrogen_kg_per_ha", "phosphorus_kg_per_ha", "potassium_kg_per_ha",
    "rainfall_to_date_mm", "irrigation_mm", "mean_temp_c",
    "max_temp_c", "solar_radiation_mj_m2", "soil_moisture_pct",
    "pest_severity", "disease_severity", "weed_severity",
    "ndvi_current", "sowing_month", "days_after_sowing",
    "previous_yield_kg_per_ha",
]
CROP_CATEGORICAL = [
    "crop", "variety", "farm_region", "soil_type", "irrigation_type",
    "previous_crop",
]


@dataclass
class Prediction:
    estimate: float
    lower: float
    upper: float
    unit: str
    method: str
    confidence_note: str
    model_version: str = ENGINE_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


def _clean_frame(df: pd.DataFrame, numeric: list[str], categorical: list[str]) -> pd.DataFrame:
    required = numeric + categorical
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required model columns: {', '.join(missing)}")
    out = df[required].copy()
    for col in numeric:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    for col in categorical:
        out[col] = out[col].astype("string").fillna("Unknown").astype(str)
    return out


def _pipeline(numeric: list[str], categorical: list[str], random_state: int = 42) -> Pipeline:
    prep = ColumnTransformer([
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), numeric),
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical),
    ])
    model = RandomForestRegressor(
        n_estimators=400,
        min_samples_leaf=2,
        max_features=0.85,
        random_state=random_state,
        n_jobs=-1,
    )
    return Pipeline([("preprocess", prep), ("model", model)])


def _split_indices(df: pd.DataFrame, group_col: Optional[str], test_size: float, random_state: int):
    idx = np.arange(len(df))
    if group_col and group_col in df.columns and df[group_col].nunique() >= 2:
        splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
        train_idx, test_idx = next(splitter.split(idx, groups=df[group_col]))
        return train_idx, test_idx, "group holdout"
    train_idx, test_idx = train_test_split(idx, test_size=test_size, random_state=random_state)
    return train_idx, test_idx, "random holdout (use farm/season groups when possible)"


def train_dairy_model(csv_path: str | Path, model_path: str | Path | None = None,
                      min_rows: int = 50, group_col: str = "animal_id") -> dict:
    """CSV target column: actual_milk_litres_day (one row per animal-day or animal-period)."""
    df = pd.read_csv(csv_path)
    target = "actual_milk_litres_day"
    if target not in df:
        raise ValueError(f"CSV must contain target column '{target}'.")
    df = df.dropna(subset=[target]).copy()
    df[target] = pd.to_numeric(df[target], errors="coerce")
    df = df.dropna(subset=[target])
    if (df[target] < 0).any():
        raise ValueError("Milk production target cannot be negative.")
    if len(df) < min_rows:
        raise ValueError(f"Need at least {min_rows} verified dairy records; found {len(df)}.")
    X = _clean_frame(df, DAIRY_NUMERIC, DAIRY_CATEGORICAL)
    y = df[target].astype(float)
    tr, te, split_method = _split_indices(df, group_col, 0.2, 42)
    pipe = _pipeline(DAIRY_NUMERIC, DAIRY_CATEGORICAL)
    pipe.fit(X.iloc[tr], y.iloc[tr])
    pred = np.maximum(0, pipe.predict(X.iloc[te]))
    metrics = {
        "records": int(len(df)), "train_records": int(len(tr)), "test_records": int(len(te)),
        "split_method": split_method,
        "mae_litres_per_animal_day": float(mean_absolute_error(y.iloc[te], pred)),
        "rmse_litres_per_animal_day": float(mean_squared_error(y.iloc[te], pred) ** 0.5),
        "r2": float(r2_score(y.iloc[te], pred)) if len(te) > 1 else None,
        "warning": "Validation is only as representative as the supplied farm data. Validate on later dates and unseen farms before commercial use.",
    }
    final_model = _pipeline(DAIRY_NUMERIC, DAIRY_CATEGORICAL)
    final_model.fit(X, y)
    path = Path(model_path) if model_path else MODEL_DIR / "dairy_model.joblib"
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": final_model, "features": DAIRY_NUMERIC + DAIRY_CATEGORICAL,
                 "target": target, "version": ENGINE_VERSION}, path)
    metrics["model_path"] = str(path)
    return metrics


def train_crop_model(csv_path: str | Path, model_path: str | Path | None = None,
                     min_rows: int = 50, group_col: str = "farm_id") -> dict:
    """CSV target column: actual_yield_kg_per_ha; use pre-harvest features only."""
    df = pd.read_csv(csv_path)
    target = "actual_yield_kg_per_ha"
    if target not in df:
        raise ValueError(f"CSV must contain target column '{target}'.")
    df = df.dropna(subset=[target]).copy()
    df[target] = pd.to_numeric(df[target], errors="coerce")
    df = df.dropna(subset=[target])
    if (df[target] < 0).any():
        raise ValueError("Crop yield target cannot be negative.")
    if len(df) < min_rows:
        raise ValueError(f"Need at least {min_rows} verified crop-season records; found {len(df)}.")
    X = _clean_frame(df, CROP_NUMERIC, CROP_CATEGORICAL)
    y = df[target].astype(float)
    tr, te, split_method = _split_indices(df, group_col, 0.2, 42)
    pipe = _pipeline(CROP_NUMERIC, CROP_CATEGORICAL)
    pipe.fit(X.iloc[tr], y.iloc[tr])
    pred = np.maximum(0, pipe.predict(X.iloc[te]))
    metrics = {
        "records": int(len(df)), "train_records": int(len(tr)), "test_records": int(len(te)),
        "split_method": split_method,
        "mae_kg_per_ha": float(mean_absolute_error(y.iloc[te], pred)),
        "rmse_kg_per_ha": float(mean_squared_error(y.iloc[te], pred) ** 0.5),
        "r2": float(r2_score(y.iloc[te], pred)) if len(te) > 1 else None,
        "warning": "Use Indian crop/region/season records and a time-based holdout where possible. Validation is not a guarantee of future accuracy.",
    }
    final_model = _pipeline(CROP_NUMERIC, CROP_CATEGORICAL)
    final_model.fit(X, y)
    path = Path(model_path) if model_path else MODEL_DIR / "crop_model.joblib"
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": final_model, "features": CROP_NUMERIC + CROP_CATEGORICAL,
                 "target": target, "version": ENGINE_VERSION}, path)
    metrics["model_path"] = str(path)
    return metrics


def _forest_interval(pipeline: Pipeline, X: pd.DataFrame, floor: float = 0.0):
    """Tree spread is a rough uncertainty indicator, not a calibrated prediction interval."""
    Xt = pipeline.named_steps["preprocess"].transform(X)
    tree_preds = np.vstack([tree.predict(Xt) for tree in pipeline.named_steps["model"].estimators_])
    estimate = float(np.mean(tree_preds[:, 0]))
    lo, hi = np.percentile(tree_preds[:, 0], [10, 90])
    return max(floor, estimate), max(floor, float(lo)), max(floor, float(hi))


def predict_dairy(features: dict[str, Any], model_path: str | Path | None = None) -> Prediction:
    path = Path(model_path) if model_path else MODEL_DIR / "dairy_model.joblib"
    if not path.exists():
        raise FileNotFoundError("Dairy model not trained. Add verified farm records and train it first.")
    bundle = joblib.load(path)
    X = _clean_frame(pd.DataFrame([features]), DAIRY_NUMERIC, DAIRY_CATEGORICAL)
    est, lo, hi = _forest_interval(bundle["pipeline"], X)
    return Prediction(round(est, 2), round(lo, 2), round(hi, 2), "litres/animal/day",
        "Random Forest trained on verified historical farm records",
        "10th–90th percentile of tree predictions; indicative only, not a statistically calibrated guarantee.")


def predict_crop(features: dict[str, Any], model_path: str | Path | None = None) -> Prediction:
    path = Path(model_path) if model_path else MODEL_DIR / "crop_model.joblib"
    if not path.exists():
        raise FileNotFoundError("Crop model not trained. Add verified crop-season records and train it first.")
    bundle = joblib.load(path)
    X = _clean_frame(pd.DataFrame([features]), CROP_NUMERIC, CROP_CATEGORICAL)
    est, lo, hi = _forest_interval(bundle["pipeline"], X)
    return Prediction(round(est, 1), round(lo, 1), round(hi, 1), "kg/hectare",
        "Random Forest trained on verified Indian crop-season records",
        "10th–90th percentile of tree predictions; indicative only, not a statistically calibrated guarantee.")


def dairy_farm_summary(per_animal_predictions: list[dict], committed_litres: float = 0.0) -> dict:
    """Each item: {'animal_count': int, 'prediction': Prediction dict or dict with estimate/lower/upper}."""
    low = mid = high = 0.0
    for item in per_animal_predictions:
        count = int(item["animal_count"])
        p = item["prediction"]
        if count < 0:
            raise ValueError("Animal count cannot be negative.")
        low += count * float(p["lower"])
        mid += count * float(p["estimate"])
        high += count * float(p["upper"])
    committed = max(0.0, float(committed_litres))
    # This is a planning estimate only; do not call it confirmed inventory.
    return {
        "estimated_daily_production_litres": round(mid, 2),
        "estimated_daily_range_litres": [round(low, 2), round(high, 2)],
        "estimated_monthly_production_litres": round(mid * 30, 2),
        "committed_orders_litres": round(committed, 2),
        "estimated_uncommitted_production_litres": round(max(0, mid - committed), 2),
        "inventory_warning": "Forecast is not actual stock. Confirm milking, quality, spoilage, reserves and delivery before listing saleable inventory.",
    }


def crop_farm_summary(prediction: dict, area_hectares: float) -> dict:
    if area_hectares <= 0:
        raise ValueError("Area must be greater than zero.")
    return {
        "estimated_total_harvest_kg": round(float(prediction["estimate"]) * area_hectares, 1),
        "estimated_total_range_kg": [
            round(float(prediction["lower"]) * area_hectares, 1),
            round(float(prediction["upper"]) * area_hectares, 1),
        ],
        "unit": "kg",
        "inventory_warning": "Forecast is not harvested stock. Confirm actual weighing, grade, moisture, losses and commitments before listing.",
    }
