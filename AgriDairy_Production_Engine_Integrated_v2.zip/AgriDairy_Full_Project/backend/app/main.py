from __future__ import annotations
import hashlib, hmac, os, secrets, sqlite3, time, json, sys, tempfile
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Request, Response, HTTPException, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel, EmailStr, Field
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[2]
ENGINE_ROOT = BASE_DIR / "production_engine"
sys.path.insert(0, str(ENGINE_ROOT.parent))
from production_engine.agridairy_engine.production_engine import (train_dairy_model, train_crop_model, predict_dairy, predict_crop, dairy_farm_summary, crop_farm_summary, DAIRY_NUMERIC, DAIRY_CATEGORICAL, CROP_NUMERIC, CROP_CATEGORICAL)
DB_PATH = Path(os.getenv("AGRIDAIRY_DB", BASE_DIR / "data" / "agridairy.db"))
SECRET = os.getenv("AGRIDAIRY_SECRET", "LOCAL-DEV-ONLY-change-before-deployment")
COOKIE = "agridairy_session"
TTL = 7 * 24 * 60 * 60
ROLES = {"Vendor", "Dairy", "Farm/Agriculture", "Driver/Logistics", "Processor", "Lab", "Admin"}
app = FastAPI(title="AgriDairy API", version="1.0.0")

def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def pw_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return salt.hex() + "$" + key.hex()

def pw_ok(password: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$", 1)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 310_000).hex()
        return hmac.compare_digest(actual, digest)
    except Exception:
        return False

def make_token(uid: int, expiry: int) -> str:
    payload = f"{uid}.{expiry}"
    sig = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return payload + "." + sig

def get_user_token(token: str):
    try:
        uid, expiry, sig = token.split(".", 2)
        payload = f"{uid}.{expiry}"
        expected = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected) or int(expiry) < int(time.time()):
            return None
        with db() as c:
            row = c.execute("SELECT id,name,email,phone,business,role,status FROM users WHERE id=?", (int(uid),)).fetchone()
        return dict(row) if row else None
    except Exception:
        return None

def signed_in(request: Request):
    token = request.cookies.get(COOKIE)
    user = get_user_token(token) if token else None
    if not user:
        raise HTTPException(401, "Please sign in.")
    return user

class Register(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=8, max_length=20)
    password: str = Field(min_length=8, max_length=128)
    role: str
    business: str = Field(min_length=2, max_length=150)

class Login(BaseModel):
    email: EmailStr
    password: str
    role: str

class Product(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    category: str
    unit: str
    price: float = Field(gt=0)
    quantity: float = Field(ge=0)
    description: str = ""

class Line(BaseModel):
    product_id: int
    quantity: float = Field(gt=0)

class Order(BaseModel):
    items: list[Line] = Field(min_length=1)
    delivery_address: str = Field(min_length=5, max_length=500)

class ProductionRecord(BaseModel):
    values: dict

class ProductionPrediction(BaseModel):
    values: dict

@app.on_event("startup")
def startup():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE COLLATE NOCASE, phone TEXT NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL, business TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Under Review', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id),
          name TEXT NOT NULL, category TEXT NOT NULL, unit TEXT NOT NULL,
          price REAL NOT NULL CHECK(price>0), quantity REAL NOT NULL DEFAULT 0 CHECK(quantity>=0),
          description TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS orders(
          id INTEGER PRIMARY KEY AUTOINCREMENT, buyer_id INTEGER NOT NULL REFERENCES users(id),
          status TEXT NOT NULL DEFAULT 'Placed', total REAL NOT NULL,
          delivery_address TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS order_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id),
          product_id INTEGER NOT NULL REFERENCES products(id), quantity REAL NOT NULL, unit_price REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS dairy_production_records(
          id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id),
          animal_id TEXT NOT NULL, record_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS crop_production_records(
          id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id),
          farm_id TEXT NOT NULL, record_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS production_model_metrics(
          kind TEXT PRIMARY KEY, metrics_json TEXT NOT NULL, trained_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS inventory_events(
          id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id),
          user_id INTEGER NOT NULL REFERENCES users(id), change_qty REAL NOT NULL,
          reason TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)

@app.get("/api/health")
def health():
    return {"status": "healthy", "application": "AgriDairy API", "version": "1.0.0"}

@app.post("/api/auth/register", status_code=201)
def register(x: Register):
    if x.role not in ROLES:
        raise HTTPException(400, "Invalid account role.")
    try:
        with db() as c:
            cur = c.execute("INSERT INTO users(name,email,phone,password_hash,role,business) VALUES(?,?,?,?,?,?)",
                (x.name.strip(), x.email.lower(), x.phone.strip(), pw_hash(x.password), x.role, x.business.strip()))
            return {"ok": True, "user_id": cur.lastrowid, "status": "Under Review"}
    except sqlite3.IntegrityError:
        raise HTTPException(409, "An account with this email already exists.")

@app.post("/api/auth/login")
def login(x: Login, response: Response):
    if x.role not in ROLES:
        raise HTTPException(400, "Invalid account role.")
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (x.email,)).fetchone()
    if not row or row["role"] != x.role or not pw_ok(x.password, row["password_hash"]):
        raise HTTPException(401, "Email, password or account role is incorrect.")
    if row["status"] != "Verified":
        raise HTTPException(403, "Your account is under review.")
    response.set_cookie(COOKIE, make_token(row["id"], int(time.time()) + TTL),
        httponly=True, secure=False, samesite="lax", max_age=TTL, path="/")
    return {"ok": True, "user": {"id":row["id"],"name":row["name"],"email":row["email"],
        "phone":row["phone"],"business":row["business"],"role":row["role"],"status":row["status"]}}

@app.get("/api/auth/me")
def me(request: Request):
    token = request.cookies.get(COOKIE)
    user = get_user_token(token) if token else None
    return {"authenticated": bool(user), "user": user}

@app.post("/api/auth/logout")
def logout(response: Response):
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}

@app.get("/api/products")
def products(category: Optional[str] = None):
    with db() as c:
        sql = """SELECT p.id,p.name,p.category,p.unit,p.price,p.quantity,p.description,
                 u.id supplier_id,u.business supplier FROM products p JOIN users u ON u.id=p.owner_id
                 WHERE p.active=1 AND u.status='Verified'"""
        args = ()
        if category:
            sql += " AND p.category=?"; args = (category,)
        rows = c.execute(sql + " ORDER BY p.id DESC", args).fetchall()
    return {"items": [dict(r) for r in rows]}

@app.post("/api/products", status_code=201)
def add_product(x: Product, user=Depends(signed_in)):
    if user["role"] not in {"Dairy", "Farm/Agriculture"}:
        raise HTTPException(403, "Only suppliers can list products.")
    with db() as c:
        cur = c.execute("""INSERT INTO products(owner_id,name,category,unit,price,quantity,description)
            VALUES(?,?,?,?,?,?,?)""",
            (user["id"],x.name.strip(),x.category,x.unit,x.price,x.quantity,x.description))
        return {"ok": True, "product_id": cur.lastrowid}

@app.get("/api/inventory")
def inventory(user=Depends(signed_in)):
    with db() as c:
        rows = c.execute("SELECT * FROM products WHERE owner_id=? ORDER BY id DESC", (user["id"],)).fetchall()
    return {"items": [dict(r) for r in rows]}

@app.get("/api/orders")
def orders(user=Depends(signed_in)):
    with db() as c:
        if user["role"] == "Vendor":
            rows = c.execute("SELECT * FROM orders WHERE buyer_id=? ORDER BY id DESC", (user["id"],)).fetchall()
        else:
            rows = c.execute("""SELECT DISTINCT o.* FROM orders o JOIN order_items i ON i.order_id=o.id
              JOIN products p ON p.id=i.product_id WHERE p.owner_id=? ORDER BY o.id DESC""", (user["id"],)).fetchall()
    return {"items": [dict(r) for r in rows]}

@app.post("/api/orders", status_code=201)
def create_order(x: Order, user=Depends(signed_in)):
    if user["role"] != "Vendor":
        raise HTTPException(403, "Only vendors can place orders.")
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        total, lines = 0.0, []
        for line in x.items:
            p = c.execute("SELECT id,price,quantity,active FROM products WHERE id=?", (line.product_id,)).fetchone()
            if not p or not p["active"]:
                raise HTTPException(404, f"Product {line.product_id} unavailable.")
            if p["quantity"] < line.quantity:
                raise HTTPException(409, f"Insufficient stock for product {line.product_id}.")
            total += p["price"] * line.quantity
            lines.append((line.product_id, line.quantity, p["price"]))
        cur = c.execute("INSERT INTO orders(buyer_id,total,delivery_address) VALUES(?,?,?)",
                        (user["id"], round(total,2), x.delivery_address))
        oid = cur.lastrowid
        for pid, qty, price in lines:
            c.execute("INSERT INTO order_items(order_id,product_id,quantity,unit_price) VALUES(?,?,?,?)",
                      (oid,pid,qty,price))
            c.execute("UPDATE products SET quantity=quantity-? WHERE id=?", (qty,pid))
            c.execute("INSERT INTO inventory_events(product_id,user_id,change_qty,reason) VALUES(?,?,?,?)",
                      (pid,user["id"],-qty,f"Reserved for order #{oid}"))
        c.commit()
        return {"ok":True,"order_id":oid,"total":round(total,2),"status":"Placed"}
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()

@app.patch("/api/orders/{order_id}/status")
def order_status(order_id: int, status: str, user=Depends(signed_in)):
    allowed = {"Accepted","Processing","Ready for Dispatch","Dispatched","Delivered","Rejected","Cancelled"}
    if status not in allowed:
        raise HTTPException(400, "Invalid status.")
    with db() as c:
        if user["role"] == "Admin":
            cur = c.execute("UPDATE orders SET status=? WHERE id=?", (status,order_id))
        else:
            cur = c.execute("""UPDATE orders SET status=? WHERE id=? AND EXISTS(
              SELECT 1 FROM order_items i JOIN products p ON p.id=i.product_id
              WHERE i.order_id=orders.id AND p.owner_id=?)""", (status,order_id,user["id"]))
        if cur.rowcount == 0:
            raise HTTPException(404, "Order not found or not permitted.")
    return {"ok":True,"order_id":order_id,"status":status}



def _production_access(user, kind):
    allowed = {"dairy": {"Dairy"}, "crop": {"Farm/Agriculture"}}
    if user["role"] not in allowed[kind] and user["role"] != "Admin":
        raise HTTPException(403, "This production module is not available for your account role.")
    if user.get("status") != "Verified":
        raise HTTPException(403, "Your account must be verified before using production records.")

def _validate_production_values(kind: str, values: dict, training: bool = False):
    numeric = DAIRY_NUMERIC if kind == "dairy" else CROP_NUMERIC
    categorical = DAIRY_CATEGORICAL if kind == "dairy" else CROP_CATEGORICAL
    required = numeric + categorical
    missing = [k for k in required if k not in values]
    if missing:
        raise HTTPException(422, "Missing required fields: " + ", ".join(missing))
    for k in numeric:
        try:
            v = float(values[k])
            if not __import__("math").isfinite(v): raise ValueError()
        except Exception:
            raise HTTPException(422, f"Field {k} must be a finite number.")
    if training:
        target = "actual_milk_litres_day" if kind == "dairy" else "actual_yield_kg_per_ha"
        if target not in values or float(values[target]) < 0:
            raise HTTPException(422, f"A non-negative {target} is required for a verified actual record.")
    return required

@app.post("/api/production/{kind}/records", status_code=201)
def add_production_record(kind: str, x: ProductionRecord, user=Depends(signed_in)):
    if kind not in {"dairy", "crop"}: raise HTTPException(404, "Unknown production type.")
    _production_access(user, kind)
    _validate_production_values(kind, x.values, training=True)
    if kind == "dairy":
        if not x.values.get("animal_id"): raise HTTPException(422, "animal_id is required.")
        table, group = "dairy_production_records", str(x.values["animal_id"])
    else:
        if not x.values.get("farm_id"): raise HTTPException(422, "farm_id is required.")
        table, group = "crop_production_records", str(x.values["farm_id"])
    with db() as c:
        c.execute(f"INSERT INTO {table}(owner_id,{ 'animal_id' if kind == 'dairy' else 'farm_id'},record_json) VALUES(?,?,?)", (user["id"], group, json.dumps(x.values)))
    return {"ok": True, "message": "Actual production record saved. It will be used only after model retraining.", "record_group": group}

@app.get("/api/production/status")
def production_status(user=Depends(signed_in)):
    _production_access(user, "dairy" if user["role"] == "Dairy" else "crop")
    with db() as c:
        d = c.execute("SELECT COUNT(*) n FROM dairy_production_records r JOIN users u ON u.id=r.owner_id WHERE u.status='Verified'").fetchone()["n"]
        cr = c.execute("SELECT COUNT(*) n FROM crop_production_records r JOIN users u ON u.id=r.owner_id WHERE u.status='Verified'").fetchone()["n"]
        metrics = {r["kind"]: json.loads(r["metrics_json"]) | {"trained_at":r["trained_at"]} for r in c.execute("SELECT * FROM production_model_metrics").fetchall()}
    return {"dairy_records": d, "crop_records": cr, "models": metrics, "minimum_records": 50, "note": "Forecasts require at least 50 verified actual records per model. A forecast is not confirmed inventory."}

@app.post("/api/production/{kind}/train")
def train_production(kind: str, user=Depends(signed_in)):
    if user["role"] != "Admin": raise HTTPException(403, "Only an administrator can train production models.")
    if kind not in {"dairy", "crop"}: raise HTTPException(404, "Unknown production type.")
    table = "dairy_production_records" if kind == "dairy" else "crop_production_records"
    group = "animal_id" if kind == "dairy" else "farm_id"
    with db() as c:
        rows = c.execute(f"SELECT r.{group},r.record_json FROM {table} r JOIN users u ON u.id=r.owner_id WHERE u.status='Verified'").fetchall()
    if len(rows) < 50: raise HTTPException(409, f"Need at least 50 verified {kind} actual records; currently have {len(rows)}.")
    records=[]
    for row in rows:
        item=json.loads(row["record_json"]); item[group]=row[group]; records.append(item)
    data_dir=BASE_DIR / "data"; data_dir.mkdir(parents=True, exist_ok=True)
    csv_path=data_dir / f"{kind}_verified_training.csv"
    pd.DataFrame(records).to_csv(csv_path,index=False)
    try:
        metrics = train_dairy_model(csv_path, min_rows=50) if kind == "dairy" else train_crop_model(csv_path, min_rows=50)
    except Exception as e:
        raise HTTPException(422, f"Model training failed: {e}")
    with db() as c:
        c.execute("INSERT INTO production_model_metrics(kind,metrics_json) VALUES(?,?) ON CONFLICT(kind) DO UPDATE SET metrics_json=excluded.metrics_json, trained_at=CURRENT_TIMESTAMP", (kind,json.dumps(metrics)))
    return {"ok":True,"kind":kind,"metrics":metrics,"message":"Model trained on verified farm records. Review metrics and validate on later seasons/unseen farms before operational use."}

@app.post("/api/production/{kind}/predict")
def production_prediction(kind: str, x: ProductionPrediction, user=Depends(signed_in)):
    if kind not in {"dairy", "crop"}: raise HTTPException(404, "Unknown production type.")
    _production_access(user, kind)
    _validate_production_values(kind, x.values, training=False)
    try:
        pred = predict_dairy(x.values).to_dict() if kind == "dairy" else predict_crop(x.values).to_dict()
    except FileNotFoundError as e:
        raise HTTPException(409, str(e))
    except Exception as e:
        raise HTTPException(422, f"Prediction failed: {e}")
    return {"prediction":pred,"warning":"Forecast only. Do not publish as saleable stock. Confirm actual production, quality, losses, reserves and existing commitments."}

@app.get("/", include_in_schema=False)
def home():
    f = BASE_DIR / "frontend" / "index.html"
    if not f.exists():
        raise HTTPException(404, "Frontend file missing.")
    return FileResponse(f)

@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)
